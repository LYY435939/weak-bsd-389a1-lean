import ExactWitness
import ExternalDataBridge
import BSD.General.QuadraticTwistLongFamily

open WeierstrassCurve
open BSD.General.QuadraticTwistTrace
namespace BSD.General.FLTLongTwist

theorem semistable_long_model_rational_twist_family
    (W : WeierstrassCurve ℤ) (hΔ : W.Δ ≠ 0) (hW : W.IsSemistableModel) :
    ∃ (a b : ℤ) (C : VariableChange ℚ),
      C • W.baseChange ℚ = (short a b).baseChange ℚ ∧
      ∀ q : ℚ, q ≠ 0 → ∃ L : ℂ → ℂ,
        BSD.Continues (short (q ^ 2 * (a : ℚ)) (q ^ 3 * (b : ℚ))) L ∧ AnalyticAt ℂ L 1 := by
  obtain ⟨N, hN, _, _, hmod⟩ := BSD.RankTwo.FLTAdapter.exact_of_semistable W hΔ hW
  let _ : NeZero N := ⟨hN.ne'⟩
  exact BSD.General.QuadraticTwistLongFamily.long_model_rational_twist_family W hΔ
    (BSD.FLTAdapter.integralModularModelData_of_flt W hmod)
end BSD.General.FLTLongTwist

#check BSD.General.FLTLongTwist.semistable_long_model_rational_twist_family
#print axioms BSD.General.FLTLongTwist.semistable_long_model_rational_twist_family
