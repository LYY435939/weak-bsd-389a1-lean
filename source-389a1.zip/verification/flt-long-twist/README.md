# 可选 FLT 外部适配：半稳定长模型的有理扭曲

本目录不参与主项目默认构建。`Wrapper.lean` 将本仓库条件性 LongFamily 定理与固定上游 FLT 六个定理组合：给定判别式非零、作为该整方程逐素性质的半稳定长 Weierstrass 模型 W，存在一个有理换元的短代表，其全部非零有理参数扭曲均有亚纯延拓且在 1 处解析。它不证明秩比较；也不假定经换元所得短方程本身半稳定。

依赖 pin：Lean 4.33.1、mathlib `0df444a360eaa60ab8c11dca51a86af692955474`、`anthropics/fermats-last-theorem` `6e837e75355538c7f80bab5b956861e86c4eacc2`，以及本仓库包含 `BSD.General.QuadraticTwistLongFamily` 的提交。本目录三个 Lean 文件是本研究的小型适配源码，不含上游证明库或其缓存。上游固定版本 [LICENSE](https://github.com/anthropics/fermats-last-theorem/blob/6e837e75355538c7f80bab5b956861e86c4eacc2/LICENSE) 和 [NOTICE](https://github.com/anthropics/fermats-last-theorem/blob/6e837e75355538c7f80bab5b956861e86c4eacc2/NOTICE) 原文副本分别为 `UPSTREAM-LICENSE`、`UPSTREAM-NOTICE`；该许可说明上游，不对本仓库其他内容作授权声明。

CPU 上实际执行过的固定路径、源码及产物哈希、各命令、失败和成功日志保存在 `.agents/evidence/flt-long-twist-20261124/`。复跑必须先按上述 pin 准备相互兼容的上游 FLT 和本项目 Lean 依赖及其构建产物，然后使其 Lean 搜索路径可见。按依赖顺序对 `ExactWitness.lean`、`ExternalDataBridge.lean`、`Wrapper.lean` 用 `lean -j1` 编译为相应的 `.olean`，使前两项输出对最后一项可见；可按收据中的 `run.sh` 和 `log/command` 复核实际参数与路径。历史命令引用临时 CPU 路径；本目录尚无经过实际验证的可移植 Lake 配置，按此说明重建全依赖的可复现性尚未测试。历史验证复用缓存，未独立核对所有传递源码与 olean 的对应。
